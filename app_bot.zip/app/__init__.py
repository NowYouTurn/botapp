"""Telegram Astrology & Payments Bot."""
__all__ = ["config", "database", "models"]
